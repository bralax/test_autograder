apt-get -y install openjdk-8-jdk

# The following lines are to make sure we can install packages from maven
# See https://bugs.launchpad.net/ubuntu/+source/ca-certificates-java/+bug/1396760
# and https://github.com/docker-library/openjdk/issues/19#issuecomment-70546872
# apt-get install --reinstall ca-certificates-java
# update-ca-certificates -f


# Try later on...
# Seems we don't need this, since we can just run it with our supplied jar
#
# apt-get -y install checkstyle
#
# Need to determine: 
# 1) Q: purpose of -y flag in jdk line above? A: it auto-answers yes to all prompts from installer
# 2) where to put check107.xml
# 3) command to run it 
# 4) likely want to capture output and report it - use same trick as with diff output?